type Supporter = {
    
    supportId: number;

    supportTierId: number;

    message: string;

    supporterId: number;

    supporterFirstName: string;

    supporterLastName: string;

    timestamp: string;

}