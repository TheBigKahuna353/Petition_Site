type Catergory = {
    categoryId : number,

    name : string,

}